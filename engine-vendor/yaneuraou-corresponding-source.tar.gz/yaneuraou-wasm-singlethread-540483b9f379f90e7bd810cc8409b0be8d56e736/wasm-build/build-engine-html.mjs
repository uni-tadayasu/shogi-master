#!/usr/bin/env node
/**
 * やねうら王(単一スレッド版wasm)を、WebView / iframe に読み込める1枚のHTMLへ束ねる。
 *
 *   node scripts/engine/build-engine-html.mjs [jsPath] [wasmPath] [outPath]
 *
 * 既定では scripts/engine/.build/yaneuraou.k-p.{js,wasm} を読み、
 * assets/engine/yaneuraou-kp.html を書き出す。
 *
 * 1枚にまとめる理由:
 *  - Expo Go の WebView は file:// から別ファイル(wasm)を fetch できない(iOSのWKWebView)。
 *    wasm を base64 で埋め込み、Worker も Blob URL から起こせば、ページ1枚で完結する。
 *  - Android の WebView は source={{html}} で渡せる文字列サイズに上限があるため、
 *    アセットとしてファイルで持ち、file:// URI で読み込む。
 *
 * ページの仕組み(生成される HTML の <script> を参照):
 *  - エンジンは Web Worker 内で動く。単一スレッド版なので "go" は bestmove まで
 *    Worker をブロックするが、Worker からの postMessage は探索中でも親へ届くので、
 *    info 行は逐次表示できる。
 *  - "stop" は Worker を terminate → 再生成で実現する(単一スレッドではコマンドを
 *    割り込ませられないため)。再生成は数十msで済む(計測値: instantiate 11ms, isready 31ms)。
 *  - 親(React Native / iframe の親ウィンドウ)との通信は JSON 1メッセージ = 1オブジェクト。
 *      親 → ページ: window.__engine.send({type:'cmd', line}) / ({type:'restart'})
 *      ページ → 親: {type:'page-ready'} {type:'ready'} {type:'line', line} {type:'stderr', line}
 *                   {type:'error', message}
 */
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const root = resolve(here, '..', '..');
const [jsArg, wasmArg, outArg] = process.argv.slice(2);
const jsPath = resolve(jsArg ?? resolve(here, '.build', 'yaneuraou.k-p.js'));
const wasmPath = resolve(wasmArg ?? resolve(here, '.build', 'yaneuraou.k-p.wasm'));
const outPath = resolve(outArg ?? resolve(root, 'assets', 'engine', 'yaneuraou-kp.html'));

const glue = readFileSync(jsPath, 'utf8');
if (glue.includes('</script')) {
  throw new Error('glue contains "</script" which would break inline embedding');
}
const wasmBase64 = readFileSync(wasmPath).toString('base64');

// Worker 側のコード。文字列として埋め込み、Blob URL から起動する。
const workerSource = String.raw`
'use strict';
var engineModule = null;
var glueLoaded = false;
self.onmessage = function (e) {
  var msg = e.data;
  if (msg.type === 'init') {
    try {
      if (!glueLoaded) {
        (0, eval)(msg.glue);
        glueLoaded = true;
      }
      YaneuraOu_K_P({
        wasmBinary: new Uint8Array(msg.wasm),
        printErr: function (line) { self.postMessage({ type: 'stderr', line: String(line) }); },
      }).then(function (mod) {
        engineModule = mod;
        mod.addMessageListener(function (line) { self.postMessage({ type: 'line', line: line }); });
        self.postMessage({ type: 'engine-ready' });
      }).catch(function (err) {
        self.postMessage({ type: 'error', message: String((err && err.stack) || err) });
      });
    } catch (err) {
      self.postMessage({ type: 'error', message: String((err && err.stack) || err) });
    }
    return;
  }
  if (msg.type === 'cmd') {
    if (!engineModule) {
      self.postMessage({ type: 'stderr', line: 'engine not initialized: ' + msg.line });
      return;
    }
    try {
      var r = engineModule.postMessage(msg.line);
      if (r !== 0) {
        self.postMessage({ type: 'stderr', line: 'engine rejected command: ' + msg.line });
      }
    } catch (err) {
      self.postMessage({ type: 'error', message: String((err && err.stack) || err) });
    }
  }
};
`;

const pageScript = String.raw`
(function () {
  'use strict';
  var RN = window.ReactNativeWebView;
  var hasParent = window.parent && window.parent !== window;
  function emit(obj) {
    if (RN) {
      RN.postMessage(JSON.stringify(obj));
    } else if (hasParent) {
      window.parent.postMessage({ __engine: obj }, '*');
    } else {
      console.log('[engine]', JSON.stringify(obj));
    }
  }

  var glue = document.getElementById('engine-glue').textContent;
  var b64 = document.getElementById('engine-wasm').textContent.replace(/\s+/g, '');
  var bin = atob(b64);
  var wasmBytes = new Uint8Array(bin.length);
  for (var i = 0; i < bin.length; i++) wasmBytes[i] = bin.charCodeAt(i);
  b64 = null;
  bin = null;

  var workerSource = document.getElementById('engine-worker').textContent;
  var workerUrl = URL.createObjectURL(new Blob([workerSource], { type: 'text/javascript' }));

  var worker = null;
  var generation = 0;

  function start() {
    generation += 1;
    var g = generation;
    try {
      worker = new Worker(workerUrl);
    } catch (err) {
      emit({ type: 'error', message: 'Worker unavailable: ' + String(err) });
      return;
    }
    worker.onmessage = function (e) {
      if (g !== generation) return;
      var m = e.data;
      if (m.type === 'engine-ready') {
        emit({ type: 'ready', generation: g });
      } else {
        emit(m);
      }
    };
    worker.onerror = function (e) {
      if (g !== generation) return;
      emit({ type: 'error', message: 'worker error: ' + (e.message || String(e)) });
    };
    // ArrayBuffer は Worker 側で消費されるので毎回コピーを渡す(再起動に備えて原本を保持)。
    var copy = wasmBytes.buffer.slice(0);
    worker.postMessage({ type: 'init', glue: glue, wasm: copy }, [copy]);
  }

  function restart() {
    if (worker) {
      try { worker.terminate(); } catch (_) { /* ignore */ }
      worker = null;
    }
    start();
  }

  window.__engine = {
    send: function (msg) {
      if (typeof msg === 'string') {
        try { msg = JSON.parse(msg); } catch (_) { return; }
      }
      if (!msg || typeof msg !== 'object') return;
      if (msg.type === 'cmd') {
        if (worker) worker.postMessage({ type: 'cmd', line: String(msg.line) });
      } else if (msg.type === 'restart') {
        restart();
      }
    },
  };

  // iframe(web版)の親ウィンドウからのコマンド。
  window.addEventListener('message', function (e) {
    if (hasParent && e.source === window.parent && e.data && e.data.__engine) {
      window.__engine.send(e.data.__engine);
    }
  });

  emit({ type: 'page-ready' });
  start();
})();
`;

const html = `<!doctype html>
<html lang="ja">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>YaneuraOu engine host</title>
</head>
<body>
<script id="engine-glue" type="text/plain">${glue}</script>
<script id="engine-worker" type="text/plain">${workerSource}</script>
<script id="engine-wasm" type="text/plain">${wasmBase64}</script>
<script>${pageScript}</script>
</body>
</html>
`;

mkdirSync(dirname(outPath), { recursive: true });
writeFileSync(outPath, html);
console.log(
  `wrote ${outPath} (${(html.length / 1024 / 1024).toFixed(2)} MB; glue ${(glue.length / 1024).toFixed(0)} KB, wasm ${(wasmBase64.length / 1024 / 1024).toFixed(2)} MB base64)`,
);
