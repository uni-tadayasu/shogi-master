// 単一スレッド版 yaneuraou.wasm 用のJS glue。
// pthread版(本家のwasm_pre.js)と同じAPI(addMessageListener/removeMessageListener/postMessage/terminate)
// を提供するが、次の点が異なる:
//  - usi_command() は同期実行される。"go" はbestmoveを出力するまで戻らない。
//    (go infinite は使わず、movetime/depth/nodes で必ず終わる探索を投げること)
//  - エンジンの出力は setTimeout を介さず、その場で listener に渡す。
//    Worker内で動かす場合、探索中でも postMessage で親へ逐次届けられる。
(function () {
  var listeners = [];

  Module["print"] = function (line) {
    if (listeners.length === 0) {
      console.log(line);
      return;
    }
    for (var i = 0; i < listeners.length; i++) listeners[i](line);
  };

  Module["addMessageListener"] = function (listener) {
    listeners.push(listener);
  };

  Module["removeMessageListener"] = function (listener) {
    var idx = listeners.indexOf(listener);
    if (idx >= 0) listeners.splice(idx, 1);
  };

  Module["terminate"] = function () {
    listeners = [];
  };

  // 1コマンドを同期実行する。戻り値 0=受理 / 1=エンジン未初期化(再送が必要)。
  Module["postMessage"] = function (command) {
    if (command === "quit") return 0;
    return Module["ccall"]("usi_command", "number", ["string"], [command]);
  };
})();
